from fastapi import FastAPI, File, UploadFile
import requests
import hmac
import hashlib
import base64
import time

app = FastAPI()

ACR_HOST = "https://identify-eu-west-1.acrcloud.com/v1/identify"
ACR_ACCESS_KEY = "YOUR_ACR_ACCESS_KEY"
ACR_ACCESS_SECRET = "YOUR_ACR_ACCESS_SECRET"

def create_signature(data_string, access_secret):
    return base64.b64encode(hmac.new(
        access_secret.encode('ascii'),
        data_string.encode('ascii'),
        digestmod=hashlib.sha1
    ).digest()).decode('ascii')

@app.post("/identify/")
async def identify_audio(file: UploadFile = File(...)):
    data = await file.read()
    http_method = "POST"
    http_uri = "/v1/identify"
    data_type = "audio"
    signature_version = "1"
    timestamp = str(int(time.time()))

    string_to_sign = "\n".join([http_method, http_uri, ACR_ACCESS_KEY, data_type, signature_version, timestamp])
    signature = create_signature(string_to_sign, ACR_ACCESS_SECRET)

    files = {
        'sample': ('sample.wav', data, 'audio/wav')
    }
    payload = {
        'access_key': ACR_ACCESS_KEY,
        'data_type': data_type,
        'signature_version': signature_version,
        'signature': signature,
        'timestamp': timestamp
    }

    response = requests.post(ACR_HOST, files=files, data=payload)
    return response.json()
